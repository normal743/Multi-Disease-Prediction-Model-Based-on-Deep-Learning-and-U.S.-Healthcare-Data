import pandas as pd
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.model_selection import train_test_split, GridSearchCV

# 读取 CSV 文件，跳过第一行第一列
data_frame = pd.read_csv("C:\\Users\\Robert Jiang\\Desktop\\maching learning\\Weight.csv", skiprows=[0])

# 删除包含缺失值的样本
data_frame.dropna(inplace=True)

# 提取特征和标签列
X = data_frame.iloc[:, 1:-1]  # 根据实际数据的列索引修改
y = data_frame.iloc[:, -1]

# 数据标准化
scaler = StandardScaler()
X = scaler.fit_transform(X)

# 处理缺失值
imputer = SimpleImputer()
X = imputer.fit_transform(X)

# 将数据集分割成训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 定义要调整的超参数范围
param_grid = {'n_neighbors': [ 6, 8,10,12,14,16,18]}

# 创建KNN分类器
knn = KNeighborsClassifier()

# 使用GridSearchCV进行超参数调整
grid_search = GridSearchCV(knn, param_grid)
grid_search.fit(X_train, y_train)

# 输出最佳超参数和对应的模型性能
print("Best Parameters:", grid_search.best_params_)
print("Best Training Accuracy:", grid_search.best_score_)

# 使用最佳超参数重新训练模型
best_knn = grid_search.best_estimator_
best_knn.fit(X_train, y_train)

# 在训练集上进行预测
y_train_pred = best_knn.predict(X_train)

# 在测试集上进行预测
y_test_pred = best_knn.predict(X_test)

# 计算训练集和测试集的准确率
train_accuracy = accuracy_score(y_train, y_train_pred)
test_accuracy = accuracy_score(y_test, y_test_pred)
print("Training Accuracy:", train_accuracy)
print("Testing Accuracy:", test_accuracy)

# 计算训练集和测试集的混淆矩阵
train_cm = confusion_matrix(y_train, y_train_pred)
test_cm = confusion_matrix(y_test, y_test_pred)
print("Training Confusion Matrix:")
print(train_cm)
print("Testing Confusion Matrix:")
print(test_cm)

# 计算训练集和测试集的分类报告
train_report = classification_report(y_train, y_train_pred)
test_report = classification_report(y_test, y_test_pred)
print("Training Classification Report:")
print(train_report)
print("Testing Classification Report:")
print(test_report)