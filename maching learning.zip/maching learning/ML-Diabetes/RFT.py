import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.model_selection import train_test_split, GridSearchCV

# 读取 CSV 文件，跳过第一行
data_frame = pd.read_csv("C:\\Users\\Robert Jiang\\Desktop\\maching learning\\Diabetes.csv", skiprows=[0])

# 删除包含缺失值的样本
data_frame.dropna(inplace=True)

# 提取特征和标签列
X = data_frame.iloc[:, :-1]
y = data_frame.iloc[:, -1]

# 处理缺失值
imputer = SimpleImputer()
X = imputer.fit_transform(X)

# 将数据集分割成训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 定义要调整的超参数网格
param_grid = {
    'n_estimators': [100,200,300,400],
    'max_depth': [None, 5, 10,15],
    'min_samples_split': [2, 5]
}

# 创建随机森林分类器
rf = RandomForestClassifier()

# 创建网格搜索对象
grid_search = GridSearchCV(estimator=rf, param_grid=param_grid, cv=5)

# 在训练集上进行网格搜索
grid_search.fit(X_train, y_train)

# 打印最佳参数组合
print("Best Parameters:", grid_search.best_params_)

# 获取最佳模型
best_model = grid_search.best_estimator_

# 在训练集上进行预测
y_train_pred = best_model.predict(X_train)

# 在测试集上进行预测
y_test_pred = best_model.predict(X_test)

# 计算训练集和测试集的准确率
train_accuracy = accuracy_score(y_train, y_train_pred)
test_accuracy = accuracy_score(y_test, y_test_pred)
print("Training Accuracy:", train_accuracy)
print("Testing Accuracy:", test_accuracy)

# 计算训练集和测试集的混淆矩阵
train_cm = confusion_matrix(y_train, y_train_pred)
test_cm = confusion_matrix(y_test, y_test_pred)
print("Training Confusion Matrix:")
print(train_cm)
print("Testing Confusion Matrix:")
print(test_cm)

# 计算训练集和测试集的分类报告
train_report = classification_report(y_train, y_train_pred)
test_report = classification_report(y_test, y_test_pred)
print("Training Classification Report:")
print(train_report)
print("Testing Classification Report:")
print(test_report)