import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.svm import SVC
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# 读取CSV数据
data = pd.read_csv("C:\\Users\\Robert Jiang\\Desktop\\maching learning\\Diabetes.csv")

# 删除包含缺失值的样本
data.dropna(inplace=True)

# 去除第一行第一列
data = data.iloc[1:, 1:]

# 将数据集拆分为特征和标签
X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values

# 数据标准化
scaler = StandardScaler()
X = scaler.fit_transform(X)

# 处理缺失数据
imputer = SimpleImputer()
X = imputer.fit_transform(X)

# 划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 类别权重
class_weights = dict()
unique_classes, class_counts = np.unique(y_train, return_counts=True)
total_samples = len(y_train)
for i in range(len(unique_classes)):
    class_weights[unique_classes[i]] = total_samples / (len(unique_classes) * class_counts[i])

# 创建SVM模型
model = SVC(class_weight=class_weights)

# 使用交叉验证评估模型性能
cv_scores = cross_val_score(model, X, y, cv=5)
print("Cross-Validation Scores:", cv_scores)
print("Average Cross-Validation Accuracy:", np.mean(cv_scores))

# 使用整个训练集训练模型
model.fit(X_train, y_train)

# 在训练集和测试集上进行预测
y_train_pred = model.predict(X_train)
y_test_pred = model.predict(X_test)

# 计算训练集和测试集的准确度
train_accuracy = accuracy_score(y_train, y_train_pred)
test_accuracy = accuracy_score(y_test, y_test_pred)

# 打印训练集和测试集的准确度
print("Training Accuracy:", train_accuracy)
print("Testing Accuracy:", test_accuracy)

# 计算测试集和训练集的混淆矩阵
train_cm = confusion_matrix(y_train, y_train_pred)
test_cm = confusion_matrix(y_test, y_test_pred)

# 打印测试集和训练集的混淆矩阵
print("Training Confusion Matrix:")
print(train_cm)
print("Testing Confusion Matrix:")
print(test_cm)

# 计算测试集和训练集的分类报告
train_report = classification_report(y_train, y_train_pred)
test_report = classification_report(y_test, y_test_pred)

# 打印测试集和训练集的分类报告
print("Training Classification Report:")
print(train_report)
print("Testing Classification Report:")
print(test_report)